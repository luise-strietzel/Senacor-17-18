package com.senacor.senacorProject;

public class Calculator {

    public static int add(int numberOne, int numberTwo){
        return numberOne + numberTwo;
    }

    public static void main(String[] args) {
        System.out.println(add(1, 2));
    }
}
